<div class="post-sec clearfix">
                <h2>Recent Posts</h2>
                <ul>
                   
                   <li class="clearfix">
                   <a href="hrlaw.php">
                   <img src="images/blog6-thump.jpg">
                   <h4>Qatar's new HR Law: A Legal Comparison</h4>
                   <p><i class=" fa fa-calendar"></i> Jan 08, 2017</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="valid-litigation-proceedings.php">
                   <img src="images/blog5-thump.jpg">
                   <h4>Valid Litigation Proceedings: A Pressing Necessity for Restitution of Rights </h4>
                   <p><i class=" fa fa-calendar"></i> Dec 19, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="sports-law.php">
                   <img src="images/blog4-thump.jpg">
                   <h4>Sports Law (Road to World Cup 2022)</h4>
                   <p><i class=" fa fa-calendar"></i> Dec 01, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="first-qatarilawfirm.php">
                   <img src="images/blog3-thump.jpg">
                   <h4>Al Sulaiti Law Firm Becomes First Qatari Law Firm to Pledge ti the UN Global...</h4>
                   <p><i class=" fa fa-calendar"></i> Nov 28, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="exit-the-state-with-no-legal-consequences.php">
                   <img src="images/blog2-thump.jpg">
                   <h4>Qatar grants 3-month amnesty period for illegal residents to exit...</h4>
                   <p><i class=" fa fa-calendar"></i> Nov 20, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="blog-details.php">
                   <img src="images/blog1-thump.jpg">
                   <h4>The SLF Blog Goes Live! Read Our First Blog-Post</h4>
                   <p><i class=" fa fa-calendar"></i> Nov 15, 2016</p>
                   </a>
                   </li>
                   
                </ul>
             </div>