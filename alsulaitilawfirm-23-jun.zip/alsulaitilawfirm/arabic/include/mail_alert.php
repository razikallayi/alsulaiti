
        <div id="mail-success" class="alert alert-success" style="display:none">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Thanks </strong>for your enquiries. We will contact you soon.
          </div>

          <div id="mail-failed" class="alert alert-danger" style="display:none">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Sorry </strong>Your mail is not sent.
          </div>
