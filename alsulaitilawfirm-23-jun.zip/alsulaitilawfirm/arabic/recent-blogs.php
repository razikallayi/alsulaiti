<div class="post-sec clearfix">
                <h2>أحدث المنشورات</h2>
                <ul>
                   
                   <li class="clearfix">
                   <a href="sports-law.php">
                   <img src="../images/blog5-thump.jpg">
                   <h4> الاختصام الصحيح للشركات ضرورة لازمة لاسترداد الحقوق </h4>
                   <p><i class=" fa fa-calendar"></i> Dec 19, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="sports-law.php">
                   <img src="../images/blog4-thump.jpg">
                   <h4>ختام فعاليات مؤتمر مناقشة القوانين الرياضية</h4>
                   <p><i class=" fa fa-calendar"></i> Dec 01, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="first-qatarilawfirm.php">
                   <img src="../images/blog3-thump.jpg">
                   <h4>مكتب السليطي للمحاماة، هو أول مكتب قطري يتعهد بالالتزام بالمبادئ العشرة للميثاق...</h4>
                   <p><i class=" fa fa-calendar"></i> Nov 28, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="exit-the-state-with-no-legal-consequences.php">
                   <img src="../images/blog2-thump.jpg">
                   <h4>قطر تمنح المقيمين بصورة غير قانونية عفواً لمدة 3 أشهر لمغادرة البلاد بدون... </h4>
                   <p><i class=" fa fa-calendar"></i> Nov 20, 2016</p>
                   </a>
                   </li>
                   
                   <li class="clearfix">
                   <a href="blog-details.php">
                   <img src="../images/blog1-thump.jpg">
                   <h4>إطلاق مدونة مكتب السليطي للمحاماة!</h4>
                   <p><i class=" fa fa-calendar"></i> Nov 15, 2016</p>
                   </a>
                   </li>
                   
                </ul>
             </div>